"use client";

// ============================================================================
// CHILD DASHBOARD — Emily's Living World 🐬
// ============================================================================
// Not a dashboard. A world that breathes, grows, and remembers.
// Built with: GSAP (timelines, parallax) + Framer Motion (transitions, gestures)
// ============================================================================

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import gsap from "gsap";
import { useGSAP } from "@gsap/react";
import { LogOut } from "lucide-react";
import { LivingWorld } from "@/components/world/LivingWorld";
import { SavingsTree } from "@/components/savings/SavingsTree";
import { SwimmingMascot } from "@/components/mascot/SwimmingMascot";
import { ADVENTURER_THEME } from "@/themes/adventurers";

gsap.registerPlugin(useGSAP);

interface ChildData {
  child: {
    name: string;
    nickname: string;
    age: number;
    avatarColor: string;
    currentAmount: number;
    goalAmount: number;
    goalName: string;
  };
  profile: {
    animalCompanion: string | null;
    theme: string;
    favoriteColor: string;
    dashboardMode: string;
  };
  tokens: { balance: number; history: any[] };
  goals: any[];
  lessons: any[];
  achievements: any[];
}

const MASCOT_EMOJI: Record<string, string> = {
  turtle: "🐢", rabbit: "🐰", chick: "🐥", panda: "🐼", penguin: "🐧", koala: "🐨",
  fox: "🦊", dolphin: "🐬", owl: "🦉", squirrel: "🐿️", raccoon: "🦝",
  eagle: "🦅", wolf: "🐺", lion: "🦁", octopus: "🐙", dragon: "🐉", leopard: "🐆",
};

export function ChildDashboardClient() {
  const router = useRouter();
  const [data, setData] = useState<ChildData | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<"home" | "goals" | "tokens" | "lessons" | "achievements">("home");
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch("/api/child/state")
      .then(r => r.json())
      .then(d => { if (d.ok) setData(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  // Hero entrance animation with GSAP
  useGSAP(() => {
    if (loading || !data) return;
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReducedMotion) return;

    const tl = gsap.timeline();
    tl.from(".hero-mascot", { y: -50, opacity: 0, duration: 0.8, ease: "back.out(1.4)" })
      .from(".hero-name", { y: 20, opacity: 0, duration: 0.5, ease: "power2.out" }, "-=0.3")
      .from(".hero-subtitle", { y: 15, opacity: 0, duration: 0.4 }, "-=0.2")
      .from(".hero-quote", { y: 10, opacity: 0, duration: 0.4 }, "-=0.1");
  }, { scope: heroRef, dependencies: [loading, data] });

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    window.location.href = "/login?fresh=" + Date.now();
  }

  if (loading) return <LoadingScreen />;
  if (!data) return <ErrorScreen onLogout={handleLogout} />;

  const { child, profile, tokens, goals, achievements } = data;
  const mascot = profile.animalCompanion || "dolphin";
  const mascotEmoji = MASCOT_EMOJI[mascot] || "🐬";
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  const savingsPct = child.goalAmount > 0 ? (child.currentAmount / child.goalAmount) * 100 : 0;

  return (
    <LivingWorld>
      {/* Swimming mascot — dolphin actually swims across the screen */}
      <SwimmingMascot emoji={mascotEmoji} size={52} />
      <div ref={heroRef} style={{ paddingBottom: "100px" }}>
        {/* ===== Hero Section ===== */}
        <div style={{ padding: "2.5rem 1.5rem 1rem", textAlign: "center", position: "relative", zIndex: 10 }}>
          {/* Mascot — breathing + floating */}
          <motion.div
            className="hero-mascot"
            animate={{
              y: [0, -10, 0],
              rotate: [0, 3, -3, 0],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            style={{ fontSize: "4.5rem", marginBottom: "0.5rem", display: "inline-block" }}
          >
            {mascotEmoji}
          </motion.div>

          <h1 className="hero-name" style={{
            fontFamily: ADVENTURER_THEME.headingFont,
            fontSize: "1.75rem",
            color: ADVENTURER_THEME.textPrimary,
            margin: 0,
            marginBottom: "0.25rem",
            textShadow: "0 2px 20px rgba(0,0,0,0.4)",
          }}>
            {greeting}, {child.nickname}
          </h1>

          <p className="hero-subtitle" style={{
            fontSize: "0.85rem",
            color: ADVENTURER_THEME.textSecondary,
            marginBottom: "0.25rem",
          }}>
            You saved {child.currentAmount.toLocaleString()} UGX this week.
          </p>

          <p className="hero-quote" style={{
            fontSize: "0.8rem",
            color: ADVENTURER_THEME.gold,
          }}>
            Your {mascot} is proud of you. 🌟
          </p>
        </div>

        {/* ===== Tab Navigation — Glass Pills ===== */}
        <div style={{
          display: "flex",
          justifyContent: "center",
          gap: "0.25rem",
          padding: "0.5rem 1rem",
          position: "sticky",
          top: 0,
          zIndex: 20,
          background: "linear-gradient(180deg, rgba(10,22,40,0.8) 0%, transparent 100%)",
          backdropFilter: "blur(12px)",
          WebkitBackdropFilter: "blur(12px)",
        }}>
          {[
            { id: "home" as const, label: "Cove", icon: "🌊" },
            { id: "goals" as const, label: "Goals", icon: "🎯" },
            { id: "tokens" as const, label: "Stars", icon: "⭐" },
            { id: "lessons" as const, label: "Learn", icon: "📖" },
            { id: "achievements" as const, label: "Badges", icon: "🏆" },
          ].map(item => (
            <motion.button
              key={item.id}
              onClick={() => setTab(item.id)}
              whileTap={{ scale: 0.92 }}
              style={{
                padding: "0.5rem 0.875rem",
                borderRadius: "999px",
                fontSize: "0.7rem",
                fontWeight: 600,
                display: "flex",
                alignItems: "center",
                gap: "0.3rem",
                whiteSpace: "nowrap",
                background: tab === item.id ? "rgba(255,255,255,0.12)" : "transparent",
                color: tab === item.id ? "#fff" : "rgba(255,255,255,0.4)",
                border: tab === item.id ? "1px solid rgba(255,255,255,0.2)" : "1px solid transparent",
                cursor: "pointer",
                transition: "all 0.3s ease",
                backdropFilter: tab === item.id ? "blur(8px)" : "none",
                WebkitBackdropFilter: tab === item.id ? "blur(8px)" : "none",
              }}
            >
              <span>{item.icon}</span>
              {item.label}
            </motion.button>
          ))}
        </div>

        {/* ===== Content ===== */}
        <div style={{ padding: "1.5rem 1rem", maxWidth: "28rem", margin: "0 auto", position: "relative", zIndex: 10 }}>
          <AnimatePresence mode="wait">
            {tab === "home" && (
              <motion.div
                key="home"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.4, ease: "easeOut" }}
                style={{ display: "flex", flexDirection: "column", gap: "1rem" }}
              >
                {/* === Savings Tree (Living) === */}
                <GlassCard>
                  <SectionLabel>{child.nickname}'s Garden 🌳</SectionLabel>
                  <SavingsTree
                    percentage={savingsPct}
                    amount={child.currentAmount}
                    goalName={child.goalName}
                  />
                </GlassCard>

                {/* === Token Wallet (Pulsing) === */}
                <GlassCard>
                  <SectionLabel>Star Wallet ⭐</SectionLabel>
                  <motion.div
                    animate={{ scale: [1, 1.04, 1] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                    style={{ textAlign: "center", padding: "0.75rem 0" }}
                  >
                    <div style={{
                      fontFamily: ADVENTURER_THEME.headingFont,
                      fontSize: "2.5rem",
                      color: ADVENTURER_THEME.gold,
                      fontWeight: 700,
                      textShadow: `0 0 25px ${ADVENTURER_THEME.gold}40`,
                    }}>
                      ⭐ {tokens.balance}
                    </div>
                    <div style={{ fontSize: "0.7rem", color: ADVENTURER_THEME.textTertiary }}>
                      Stars earned
                    </div>
                  </motion.div>
                </GlassCard>

                {/* === Goals Preview === */}
                <GlassCard>
                  <SectionLabel>My Goals 🎯</SectionLabel>
                  {goals.length === 0 ? (
                    <EmptyText>No goals yet. Ask your parent to set one!</EmptyText>
                  ) : (
                    <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
                      {goals.slice(0, 3).map((g, i) => (
                        <motion.div
                          key={g.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.1 }}
                        >
                          <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.85rem", color: "#fff", marginBottom: "0.25rem" }}>
                            <span>{g.title}</span>
                            <span style={{ color: ADVENTURER_THEME.gold }}>{g.progressPct}%</span>
                          </div>
                          <div style={{ width: "100%", height: "6px", background: "rgba(255,255,255,0.08)", borderRadius: "3px", overflow: "hidden" }}>
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${g.progressPct}%` }}
                              transition={{ duration: 0.8, delay: 0.2 + i * 0.1, ease: "easeOut" }}
                              style={{ height: "100%", background: `linear-gradient(90deg, ${ADVENTURER_THEME.coral}, ${ADVENTURER_THEME.gold})`, borderRadius: "3px" }}
                            />
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </GlassCard>
              </motion.div>
            )}

            {tab === "goals" && (
              <motion.div key="goals" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}>
                <GlassCard>
                  <SectionLabel>My Goals 🎯</SectionLabel>
                  {goals.length === 0 ? (
                    <EmptyText>No goals yet. Ask your parent to create one for you!</EmptyText>
                  ) : (
                    <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
                      {goals.map((g, i) => (
                        <motion.div key={g.id} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.1 }} style={{ padding: "1rem", background: "rgba(255,255,255,0.04)", borderRadius: "0.75rem" }}>
                          <div style={{ fontSize: "1rem", fontWeight: 600, color: "#fff", marginBottom: "0.5rem" }}>{g.title}</div>
                          <div style={{ fontSize: "0.7rem", color: ADVENTURER_THEME.textTertiary, marginBottom: "0.5rem" }}>
                            {g.currentAmount.toLocaleString()} / {g.targetAmount.toLocaleString()}
                          </div>
                          <div style={{ width: "100%", height: "10px", background: "rgba(255,255,255,0.08)", borderRadius: "5px", overflow: "hidden" }}>
                            <motion.div initial={{ width: 0 }} animate={{ width: `${g.progressPct}%` }} transition={{ duration: 0.8, delay: 0.2 }} style={{ height: "100%", background: `linear-gradient(90deg, ${ADVENTURER_THEME.coral}, ${ADVENTURER_THEME.gold})`, borderRadius: "5px" }} />
                          </div>
                          <div style={{ textAlign: "right", fontSize: "0.7rem", color: ADVENTURER_THEME.gold, marginTop: "0.25rem" }}>{g.progressPct}%</div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </GlassCard>
              </motion.div>
            )}

            {tab === "tokens" && (
              <motion.div key="tokens" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}>
                <GlassCard>
                  <SectionLabel>Star Wallet ⭐</SectionLabel>
                  <motion.div animate={{ scale: [1, 1.05, 1] }} transition={{ duration: 3, repeat: Infinity }} style={{ textAlign: "center", padding: "1.5rem 0" }}>
                    <div style={{ fontFamily: ADVENTURER_THEME.headingFont, fontSize: "3rem", color: ADVENTURER_THEME.gold, fontWeight: 700, textShadow: `0 0 25px ${ADVENTURER_THEME.gold}40` }}>
                      ⭐ {tokens.balance}
                    </div>
                    <div style={{ fontSize: "0.8rem", color: ADVENTURER_THEME.textTertiary }}>Total stars</div>
                  </motion.div>
                  {tokens.history.length > 0 && (
                    <div>
                      <div style={{ fontSize: "0.65rem", fontWeight: 600, color: ADVENTURER_THEME.textTertiary, marginBottom: "0.5rem", textTransform: "uppercase", letterSpacing: "0.1em" }}>History</div>
                      {tokens.history.slice(0, 10).map((t, i) => (
                        <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }} style={{ display: "flex", justifyContent: "space-between", padding: "0.5rem 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                          <div>
                            <div style={{ fontSize: "0.8rem", color: "#fff" }}>{t.type === "parent_give" ? "⭐ Earned" : "🔄 Redeemed"}</div>
                            <div style={{ fontSize: "0.7rem", color: ADVENTURER_THEME.textTertiary }}>{t.note}</div>
                          </div>
                          <div style={{ fontSize: "0.85rem", fontWeight: 600, color: t.type === "parent_give" ? ADVENTURER_THEME.mint : ADVENTURER_THEME.coral }}>
                            {t.type === "parent_give" ? "+" : "−"}{t.tokens}
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </GlassCard>
              </motion.div>
            )}

            {tab === "lessons" && (
              <motion.div key="lessons" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}>
                <GlassCard>
                  <SectionLabel>Learn 📖</SectionLabel>
                  <EmptyText>Lessons coming soon! Your parent will assign financial stories for you.</EmptyText>
                  <motion.div whileHover={{ scale: 1.02, y: -2 }} style={{ marginTop: "0.5rem", padding: "1rem", background: "rgba(255,255,255,0.04)", borderRadius: "0.75rem", cursor: "pointer" }}>
                    <div style={{ fontSize: "0.85rem", color: "#fff", marginBottom: "0.25rem" }}>📖 The Dolphin Learns Patience</div>
                    <div style={{ fontSize: "0.7rem", color: ADVENTURER_THEME.textTertiary }}>Coming soon</div>
                  </motion.div>
                </GlassCard>
              </motion.div>
            )}

            {tab === "achievements" && (
              <motion.div key="achievements" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}>
                <GlassCard>
                  <SectionLabel>Badges 🏆</SectionLabel>
                  {achievements.length === 0 ? (
                    <EmptyText>No badges yet. Save money, complete lessons, and earn stars to unlock badges!</EmptyText>
                  ) : (
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem" }}>
                      {achievements.map((a, i) => (
                        <motion.div key={i} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.1, type: "spring", bounce: 0.5 }} style={{ textAlign: "center", padding: "1rem", background: "rgba(255,255,255,0.04)", borderRadius: "0.75rem" }}>
                          <div style={{ fontSize: "2rem" }}>{a.icon || "🏆"}</div>
                          <div style={{ fontSize: "0.75rem", fontWeight: 600, color: "#fff", marginTop: "0.25rem" }}>{a.title}</div>
                          <div style={{ fontSize: "0.6rem", color: ADVENTURER_THEME.gold }}>+{a.points} pts</div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </GlassCard>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ===== Logout ===== */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={handleLogout}
          style={{
            position: "fixed",
            bottom: "1.5rem",
            right: "1.5rem",
            width: "48px",
            height: "48px",
            borderRadius: "50%",
            background: "rgba(255,255,255,0.08)",
            border: "1px solid rgba(255,255,255,0.12)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer",
            zIndex: 30,
            backdropFilter: "blur(10px)",
            WebkitBackdropFilter: "blur(10px)",
          }}
          aria-label="Log out"
        >
          <LogOut style={{ width: "18px", height: "18px", color: "rgba(255,255,255,0.5)" }} />
        </motion.button>
      </div>
    </LivingWorld>
  );
}

// ===== Shared Components =====

function GlassCard({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      whileHover={{ y: -2 }}
      style={{
        background: ADVENTURER_THEME.glassBg,
        borderRadius: "1.25rem",
        padding: "1.25rem",
        border: `1px solid ${ADVENTURER_THEME.glassBorder}`,
        backdropFilter: "blur(20px)",
        WebkitBackdropFilter: "blur(20px)",
        boxShadow: ADVENTURER_THEME.glassShadow,
      }}
    >
      {children}
    </motion.div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div style={{
      fontSize: "0.7rem",
      fontWeight: 600,
      color: ADVENTURER_THEME.textSecondary,
      textTransform: "uppercase",
      letterSpacing: "0.1em",
      marginBottom: "0.75rem",
    }}>
      {children}
    </div>
  );
}

function EmptyText({ children }: { children: React.ReactNode }) {
  return (
    <div style={{
      textAlign: "center",
      padding: "1.5rem 0",
      fontSize: "0.85rem",
      color: ADVENTURER_THEME.textTertiary,
    }}>
      {children}
    </div>
  );
}

function LoadingScreen() {
  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: ADVENTURER_THEME.bgDeep }}>
      <div style={{ textAlign: "center" }}>
        <motion.div
          animate={{ y: [0, -12, 0], rotate: [0, 5, -5, 0] }}
          transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
          style={{ fontSize: "3.5rem", marginBottom: "1rem" }}
        >
          🐬
        </motion.div>
        <motion.div
          animate={{ opacity: [0.3, 1, 0.3] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          style={{ color: "rgba(255,255,255,0.5)", fontSize: "0.85rem", letterSpacing: "0.15em" }}
        >
          Entering your world...
        </motion.div>
      </div>
    </div>
  );
}

function ErrorScreen({ onLogout }: { onLogout: () => void }) {
  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: ADVENTURER_THEME.bgDeep }}>
      <div style={{ textAlign: "center" }}>
        <p style={{ color: "rgba(255,255,255,0.6)", marginBottom: "1rem" }}>Something went wrong.</p>
        <button onClick={onLogout} style={{ padding: "0.5rem 1.5rem", borderRadius: "0.5rem", background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.12)", color: "#fff", cursor: "pointer" }}>
          Back to Login
        </button>
      </div>
    </div>
  );
}
