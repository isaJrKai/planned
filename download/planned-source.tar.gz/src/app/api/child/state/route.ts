// app/api/child/state/route.ts — Get child's own data (filtered, no family data)
import { NextResponse } from "next/server";
import { getAuthUser } from "@/lib/auth";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  const user = await getAuthUser();
  if (!user) return NextResponse.json({ ok: false, error: "Not authenticated" }, { status: 401 });
  if (user.familyRole !== "CHILD") return NextResponse.json({ ok: false, error: "Not a child account" }, { status: 403 });

  // Get child's profile
  const childProfile = await db.childProfile.findFirst({
    where: { userId: user.id },
  });
  if (!childProfile) return NextResponse.json({ ok: false, error: "Child profile not found" }, { status: 404 });

  // Get ONLY this child's data — NO family data, NO sibling data
  const child = await db.child.findUnique({
    where: { id: childProfile.childId },
  });
  if (!child) return NextResponse.json({ ok: false, error: "Child record not found" }, { status: 404 });

  // Get this child's tokens only
  const tokenLedger = await db.tokenLedgerEntry.findMany({
    where: { childId: child.id },
    orderBy: { timestamp: "desc" },
    take: 20,
  });

  // Get this child's goals only
  const goals = await db.goal.findMany({
    where: { ownerId: child.id },
    orderBy: { createdAt: "desc" },
  });

  // Calculate token balance
  const tokensGiven = tokenLedger.filter(t => t.type === "parent_give").reduce((s, t) => s + t.tokens, 0);
  const tokensRedeemed = tokenLedger.filter(t => t.type === "redeem").reduce((s, t) => s + t.tokens, 0);
  const tokenBalance = tokensGiven - tokensRedeemed;

  // Get child preferences
  const prefs = await db.childPreferences.findUnique({ where: { childId: childProfile.id } });

  // Get lessons progress
  const lessonProgress = await db.lessonProgress.findMany({
    where: { userId: user.id },
  });

  // Get achievements
  const achievements = await db.userAchievement.findMany({
    where: { userId: user.id },
    include: { achievement: true },
  });

  return NextResponse.json({
    ok: true,
    child: {
      name: child.name,
      nickname: childProfile.nickname,
      age: child.age,
      avatarColor: child.avatarColor,
      avatarPhoto: child.avatarPhoto,
      currentAmount: child.currentAmount,
      goalAmount: child.goalAmount,
      goalName: child.goalName,
    },
    profile: {
      animalCompanion: childProfile.animalCompanion,
      theme: childProfile.theme,
      favoriteColor: childProfile.favoriteColor,
      dashboardMode: childProfile.dashboardMode,
    },
    preferences: prefs,
    tokens: {
      balance: tokenBalance,
      history: tokenLedger.map(t => ({
        type: t.type,
        tokens: t.tokens,
        note: t.note,
        timestamp: Number(t.timestamp),
      })),
    },
    goals: goals.map(g => ({
      id: g.id,
      title: g.title,
      targetAmount: g.targetAmount,
      currentAmount: g.currentAmount,
      progressPct: g.targetAmount > 0 ? Math.round((g.currentAmount / g.targetAmount) * 100) : 0,
    })),
    lessons: lessonProgress.map(l => ({
      lessonId: l.lessonId,
      status: l.status,
      score: (l as any).score ?? null,
    })),
    achievements: achievements.map(a => ({
      code: a.achievement?.code,
      title: a.achievement?.title,
      icon: a.achievement?.icon,
      points: a.achievement?.points,
    })),
  });
}
