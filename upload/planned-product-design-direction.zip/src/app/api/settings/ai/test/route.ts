import { handler, ok, rateLimit } from "@/lib/api";
import { requireParent } from "@/lib/auth";
import { interpret } from "@/lib/ai";

export const POST = handler(async () => {
  const v = await requireParent();
  rateLimit(`aitest:${v.family.id}`, 5, 60 * 1000);
  const r = await interpret(v.family.id, "In one sentence, confirm you can read this context.", { family: v.family.name, check: "ok" }, "parent");
  return ok(r);
});
